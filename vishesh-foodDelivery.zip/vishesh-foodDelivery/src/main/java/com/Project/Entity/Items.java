package com.Project.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Items {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int itemid;
	private String itemName;
	private Long price;
	private int count;
	
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public Items(String itemName, Long price, int count) {
		super();
		this.itemName = itemName;
		this.price = price;
		this.count = count;
	}
	
	public Items() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", itemName=" + itemName + ", price=" + price + ", count=" + count + "]";
	}
	
}
