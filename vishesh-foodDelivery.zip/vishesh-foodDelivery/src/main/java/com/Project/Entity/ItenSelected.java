package com.Project.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ItenSelected {
	@Id
	private int id;
}
