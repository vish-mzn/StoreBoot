package com.Project.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Project.Entity.Items;

@Repository
public interface ItemsRepository extends CrudRepository<Items, Integer> {

}
