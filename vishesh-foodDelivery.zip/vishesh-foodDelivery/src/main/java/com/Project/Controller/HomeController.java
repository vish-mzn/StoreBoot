package com.Project.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Project.Entity.Items;
import com.Project.Service.ItemService;

@Controller
public class HomeController {
	
	@Autowired
	private ItemService itemService;
	
	@RequestMapping("/index")
	private String homepage(Model model)
	{
		//itemService.createTables();
		List<Items> itemlist = itemService.listAllItems();
		
		model.addAttribute("itemlist", itemlist);
		return "homeScreen";
	}
	
	@RequestMapping("/placeOrder")
	private String order(HttpServletRequest request)
	{
		int q = Integer.parseInt(request.getParameter("count"));
		System.out.println(q);
		Items item = 
		
		return "forward:/index";
	}
	
	@RequestMapping("/cart")
	private String cart()
	{
		return "forward:/index";
	}
	
}
