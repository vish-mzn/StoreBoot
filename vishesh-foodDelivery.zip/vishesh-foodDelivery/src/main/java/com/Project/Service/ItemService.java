package com.Project.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.DAO.ItemsRepository;
import com.Project.Entity.Items;

@Service
public class ItemService 
{
	@Autowired
	private ItemsRepository itemRepository;
	
	public List<Items> listAllItems() {
		List<Items> listOfItems = (List<Items>) itemRepository.findAll();
		return listOfItems;
	}

	public void createTables() {
		Items i1 = new Items("Veg Biriyani", 120L, 15);
		Items i2 = new Items("Chiken Biriyani", 160L, 15);
		Items i3 = new Items("Meda Vada", 40L, 15);
		Items i4 = new Items("Dosa", 80L, 15);
		
		itemRepository.save(i1);
		itemRepository.save(i2);
		itemRepository.save(i3);
		itemRepository.save(i4);
	}
	
}
