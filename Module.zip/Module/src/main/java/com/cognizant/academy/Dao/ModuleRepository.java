package com.cognizant.academy.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.academy.Model.Module;

@Repository("module")
public interface ModuleRepository extends CrudRepository<Module,Integer> {

	@Query("from Module m where m.course.id=:course_id")
	public List<Module> getmodlist(@Param("course_id")String course_id);
	
	@Query("from Module m where m.name=:module")
	public Module getModule_id(@Param("module")String module);
	
}
