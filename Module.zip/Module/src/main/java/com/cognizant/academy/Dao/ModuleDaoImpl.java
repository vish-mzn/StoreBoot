package com.cognizant.academy.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.Stack;

@Repository("module_dao")
public class ModuleDaoImpl implements ModuleDao {

	@Autowired
	CourseRepository course;

	@Autowired
	ModuleRepository module;

	@Autowired
	StackRepository stack;

	@Autowired
	ObjectiveRepository objective;

	@Override
	public List<Module> getmodlist(String course_id) {
		return (List<Module>) module.findAll();
	}

	@Override
	public void add(Module obj) {
		module.save(obj);

	}

	@Override
	public List<Stack> getStacklist() {
		return (List<Stack>) stack.findAll();
	}

	@Override
	public List<Objective> getModuleObjectives(int mod_id) {
		try
		{
		return (List<Objective>) objective.getModuleObjectives(mod_id);
		}
		catch(NullPointerException e)
		{
			System.out.println("empty");
			return null;
		}

	}

	@Override
	public List<Objective> getStackObjectives(int stack_id) {
		return (List<Objective>) objective.getStackObjectives(stack_id);
	}

	@Override
	public void addObjectiveToModule(int module_id, int objective_id) {
		Objective obj = objective.findOne(objective_id);
		Module mod = module.findOne(module_id);
		obj.setModule(mod);
		objective.save(obj);

	}

	@Override
	public void removeObjective(int objective_id) {
		Objective obj = objective.findOne(objective_id);
		obj.setModule(null);
		objective.save(obj);

	}

	@Override
	public int getStack_id(String stacks) {
		Stack s= stack.getStack_id(stacks);
		return s.getId();
	}

	@Override
	public int getModule_id(String module_name) {

		
		try {
		Module mod=module.getModule_id(module_name);
		System.out.println(mod.getId());
		return mod.getId();
		}
		catch(NullPointerException e)
		{
			return 0;
		}
	}

	@Override
	public int getObjective_id(String objective_name) {
		Objective obj=objective.getObjective_id(objective_name);
		return obj.getId();
	}

	@Override
	public void insertCourse(Course c) {
		course.save(c);
	}

	@Override
	public void insertModule(Module m) {
		module.save(m);

	}

	@Override
	public void insertStack(Stack s) {
		stack.save(s);

	}

	@Override
	public void insertObj(Objective o1) {
		objective.save(o1);

	}

	@Override
	public Course getCourse(int course_id) {
		return (Course)course.findOne(course_id);
	}

}
