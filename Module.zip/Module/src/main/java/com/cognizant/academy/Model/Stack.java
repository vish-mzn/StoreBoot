package com.cognizant.academy.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity

@Table(name="stack")
public class Stack implements Serializable
{
	public static final long serialVersionUID = 1L;
	private
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String name;
	@OneToMany(mappedBy = "stack", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Objective> objlist = new ArrayList<Objective>();
	
	public List<Objective> getObjlist() {
		return objlist;
	}
	public void setObjlist(List<Objective> objlist) {
		this.objlist = objlist;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String stack_name) {
		this.name = stack_name;
	}
	
	
}
