package com.cognizant.academy.Dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.academy.Model.Course;

@Repository("course")
public interface CourseRepository extends CrudRepository<Course, Integer> {


}
