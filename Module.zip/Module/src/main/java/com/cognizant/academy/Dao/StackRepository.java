package com.cognizant.academy.Dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.academy.Model.Stack;

@Repository("stack")
public interface StackRepository extends CrudRepository<Stack,Integer>  {
   
	@Query("from Stack s where s.name=:stacks")
	public Stack getStack_id(@Param("stacks")String stacks);
}
