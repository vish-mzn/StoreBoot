package com.cognizant.academy.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.ObjectiveJsp;
import com.cognizant.academy.Service.ModuleService;
import com.cognizant.academy.Service.ModuleServiceImpl;

@Controller
public class ModuleServ {

	@Autowired(required = true)
	private ModuleService bo;

	@RequestMapping("/")
	public String homePage() {
		return "NewFile";
	}

	@RequestMapping("/getModules/{course_id}")
	public ModelAndView getModuleList(@PathVariable String course_id, HttpServletRequest request, Model model) {
		System.out.println(course_id);
		// bo.createTables();
		HttpSession session = request.getSession();
		if (course_id.equalsIgnoreCase((String) session.getAttribute("Mod_course"))) {
		} else {
			session.removeAttribute("Mod");
			session.setAttribute("Mod", null);
		}
		session.setAttribute("Mod_course", course_id);
		Course c = bo.getCourseName(course_id);
		model.addAttribute("Course", c.getName());
		// Fetching Module list for course_id

		List<String> mlist = bo.getModule_list(course_id);
		model.addAttribute("ModList", mlist);
		String modhead = null;

		modhead = (String) session.getAttribute("Mod");

		if (modhead == null) {
			model.addAttribute("Modhead", "Select Module");
		} else {
			model.addAttribute("Modhead", modhead);
		}
		return new ModelAndView("Modules", "module", new Module());
	}

	@RequestMapping(value = "getModules/addModule", method = RequestMethod.POST)
	public ModelAndView addModule(@ModelAttribute("module") Module module, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String c = (String) session.getAttribute("Mod_course");
		int course_id = Integer.parseInt(c);
		bo.addModule(module, course_id);
		return new ModelAndView("redirect:/getModules/" + course_id);
	}

	@RequestMapping(value = "getModules/addObjective", method = RequestMethod.POST)
	public ModelAndView addObjective(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String c = (String) session.getAttribute("Mod_course");
		int course_id = Integer.parseInt(c);
		String Mod_name = (String) session.getAttribute("Mod");
		System.out.println(Mod_name);
		String Objective = request.getParameter("objective");
		bo.addObjective(Mod_name, Objective);
		return new ModelAndView("redirect:/getModules/" + course_id);
	}

	@RequestMapping(value = "getModules/deleteObj", method = RequestMethod.POST)
	public ModelAndView deleteObjective(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String c = (String) session.getAttribute("Mod_course");
		int course_id = Integer.parseInt(c);
		String[] names = request.getParameterValues("chk1");

		for (String s : names) {
			System.out.println(s);
			bo.removeObjective(s);
		}
		return new ModelAndView("redirect:/getModules/" + course_id);
	}

	@RequestMapping(value = "getModules/fetchModuleObj", produces = "application/json")
	public @ResponseBody List<ObjectiveJsp> fetchModuleObj(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Inside");
		HttpSession session = request.getSession();
		String Mod_name = request.getParameter("module");
		System.out.println(Mod_name);

		session.setAttribute("Mod", Mod_name);
		List<ObjectiveJsp> olist = bo.fetchobj(Mod_name);
		return olist;

	}

	@RequestMapping(value = "getModules/stacklist", produces = "application/json")
	public @ResponseBody List<String> getStackList(HttpServletRequest request, HttpServletResponse response) {

		List<String> slist = bo.getStack_list();
		return slist;

	}

	@RequestMapping(value = "getModules/fetchModuleObjreload", produces = "application/json")
	public @ResponseBody List<ObjectiveJsp> fetchModuleobjReloading(HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Inside");
		HttpSession session = request.getSession();
		String Mod_name = (String) session.getAttribute("Mod");
		List<ObjectiveJsp> olist = bo.fetchobj(Mod_name);
		return olist;
	}

	@RequestMapping(value = "getModules/objList", produces = "application/json")
	public @ResponseBody List<String> getObjectiveList(HttpServletRequest request, HttpServletResponse response) {
		// Method to fetch list of objective for selected stack
		String stack = request.getParameter("stack_name");
		List<String> olist = bo.fetchObjective_names(stack);
		return olist;
	}

	@RequestMapping(value = "getModules/validate_modname", produces = "application/json")
	public @ResponseBody List<String> validate_modname(HttpServletRequest request, HttpServletResponse response) {
		// Method to fetch list of objective for selected stack
		String name = request.getParameter("mod_name");
		List<String> result = bo.check_Modname(name);
		return result;
	}
}
