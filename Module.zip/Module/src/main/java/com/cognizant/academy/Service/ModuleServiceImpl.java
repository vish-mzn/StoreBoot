package com.cognizant.academy.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.academy.Dao.ModuleDao;
import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.ObjectiveJsp;
import com.cognizant.academy.Model.Stack;

@Service("bo")
public class ModuleServiceImpl implements ModuleService {
	@Autowired(required = true)
	private ModuleDao module_dao;

	@Transactional
	public List<String> getModule_list(String course_id) // getiing list of module and returning list of module name
	{
		List<Module> modlist = module_dao.getmodlist(course_id);
		List<String> list = new ArrayList<String>();
		for (Module m : modlist) {
			list.add(m.getName());
		}
		return list;
	}

	@Transactional
	public void addModule(Module module, int course_id) {
		Course c = module_dao.getCourse(course_id);
		module.setCourse(c);
		module_dao.add(module);

	}

	@Transactional
	public List<String> getStack_list() {

		List<Stack> stackList = module_dao.getStacklist();
		List<String> list = new ArrayList<String>();
		for (Stack s : stackList) {
			list.add(s.getName());
		}
		return list;
	}

	@Transactional
	public List<ObjectiveJsp> fetchobj(String name) {

		int mod_id = module_dao.getModule_id(name.trim());
		System.out.println(mod_id);
		List<Objective> objList = module_dao.getModuleObjectives(mod_id);
		List<ObjectiveJsp> list = new ArrayList<ObjectiveJsp>();
		for (Objective o : objList) {
			ObjectiveJsp oj = new ObjectiveJsp();
			oj.setId(o.getId());
			oj.setName(o.getName());
			oj.setStack_name(o.getStack().getName());
			oj.setDuration(o.getDuration());
			list.add(oj);
		}
		return list;
	}

	@Transactional
	public List<String> fetchObjective_names(String stack) {

		int stack_id = module_dao.getStack_id(stack);
		System.out.println("stack" + stack_id);
		List<Objective> objList = module_dao.getStackObjectives(stack_id);
		System.out.println(objList);
		List<String> list = new ArrayList<String>();
		for (Objective o : objList) {
			list.add(o.getName());
		}
		return list;
	}

	@Transactional
	public void addObjective(String module, String objective) {

		int mod_id = module_dao.getModule_id(module.trim());
		int obj_id = module_dao.getObjective_id(objective);
		module_dao.addObjectiveToModule(mod_id, obj_id);

	}

	@Transactional
	public void removeObjective(String s) {

		int obj_id = module_dao.getObjective_id(s.trim());
		module_dao.removeObjective(obj_id);
	}

	@Transactional
	public void createTables() {

		Course c = new Course();
		c.setName("Web Development");
		module_dao.insertCourse(c);

		Module m = new Module();
		m.setName("Arsh");
		m.setCourse(c);
		module_dao.insertModule(m);

		Module m1 = new Module();
		m1.setName("Aftab");
		m1.setCourse(c);
		module_dao.insertModule(m1);

		Stack s = new Stack();
		s.setName("HTML");
		module_dao.insertStack(s);

		Stack s1 = new Stack();
		s1.setName("Css");
		module_dao.insertStack(s1);

		Objective o1 = new Objective();
		o1.setName("obj1");
		o1.setDuration(150);
		o1.setModule(null);
		o1.setStack(s);
		module_dao.insertObj(o1);

		Objective o2 = new Objective();
		o2.setName("obj2");
		o2.setDuration(120);
		o2.setModule(null);
		o2.setStack(s);
		module_dao.insertObj(o2);

		Objective o3 = new Objective();
		o3.setName("obj3");
		o3.setDuration(100);
		o3.setModule(null);
		o3.setStack(s1);
		module_dao.insertObj(o3);

		Objective o4 = new Objective();
		o4.setName("obj4");
		o4.setDuration(90);
		o4.setModule(null);
		o4.setStack(s1);
		module_dao.insertObj(o4);

	}

	@Transactional
	public Course getCourseName(String course_id) {

		int co = Integer.parseInt(course_id);
		Course c = module_dao.getCourse(co);
		return c;
	}

	@Transactional
	public List<String> check_Modname(String name) {
		String regex = "[A-Za-z0-9]{0,}";
		List<String> list = new ArrayList<String>();
		if (name == "") {
			list.add("Can't leave empty");
			return list;
		}
		if ((name.matches(regex)) == false) {
			list.add("Only alphanumeric characters allowed");
			return list;
		}

		int mod_id = module_dao.getModule_id(name.trim());
		if (mod_id == 0) {
			list.add("");
			return list;
		} else {
			list.add("Module Already exists");
			return list;
		}
	}
}
