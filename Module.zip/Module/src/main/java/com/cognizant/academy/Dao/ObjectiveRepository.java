package com.cognizant.academy.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.academy.Model.Objective;

@Repository("objective")
public interface ObjectiveRepository extends CrudRepository<Objective, Integer> {

	@Query("from Objective o where o.module.id=:mod_id")
	public List<Objective> getModuleObjectives(@Param("mod_id") int mod_id);

	@Query("from Objective o where o.module.id=null and o.stack.id=:stack_id")
	public List<Objective> getStackObjectives(@Param("stack_id") int stack_id);

	@Query("from Objective o where o.name=:objective_name")
	public Objective getObjective_id(@Param("objective_name") String objective_name);

}
