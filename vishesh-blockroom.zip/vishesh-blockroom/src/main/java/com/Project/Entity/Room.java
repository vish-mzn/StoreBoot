package com.Project.Entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int ro_id;
	private Long ro_room_number;
	
	@OneToMany(mappedBy = "room", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Room_Blocking> list = new ArrayList<Room_Blocking>();
	
	public Room() {
		super();
	}
	
	public int getRo_id() {
		return ro_id;
	}
	public void setRo_id(int ro_id) {
		this.ro_id = ro_id;
	}
	public Long getRo_room_number() {
		return ro_room_number;
	}
	public void setRo_room_number(Long ro_room_number) {
		this.ro_room_number = ro_room_number;
	}
	public List<Room_Blocking> getList() {
		return list;
	}
	public void setList(List<Room_Blocking> list) {
		this.list = list;
	}
	
	public Room(Long ro_room_number) {
		this.ro_room_number = ro_room_number;
	}
	
	@Override
	public String toString() {
		return "Room [ro_id=" + ro_id + ", ro_room_number=" + ro_room_number + "]";
	}
	
}
