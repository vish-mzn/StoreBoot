package com.Project.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Room_Blocking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int rb_id;
	private Date ro_date;
	
	@ManyToOne
	private Room room;

	public int getRb_id() {
		return rb_id;
	}
	public void setRb_id(int rb_id) {
		this.rb_id = rb_id;
	}
	public Date getRo_date() {
		return ro_date;
	}
	public void setRo_date(Date ro_date) {
		this.ro_date = ro_date;
	}
	
	@JoinColumn(name = "rb_ro_id")
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	
}
