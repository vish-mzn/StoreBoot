package com.Project.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Project.Entity.Room;
import com.Project.Entity.Room_Blocking;
import com.Project.Service.RoomService;

@Controller
public class HomeController {
	
	@Autowired
	private RoomService roomService;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	@RequestMapping("/index")
	private String homepage(Model model)
	{
		//roomService.createTables();
		List<Room> listRoom = roomService.listAllRoom();
		List<Room_Blocking> listRoom_Blocking = roomService.listAllRoomBlocking();
		
		model.addAttribute("bookingList", listRoom_Blocking);
		model.addAttribute("listRoom", listRoom);
		return "homeScreen";
	}
	
	@PostMapping("/check")
	private String bookingDates(HttpServletRequest request, Model model)
	{
		Date date = null;
		int roomId = Integer.parseInt(request.getParameter("roomNo"));
		try {
			date = sdf.parse(request.getParameter("date"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		boolean check = roomService.checkAvailability(date, roomId);
		
		if(check==true)
		{
			model.addAttribute("status","Room not Available");
		}
		else
		{
			roomService.bookRoom(date, roomId);
			model.addAttribute("status","Room Booked");
		}
	
		return "forward:/index";
	}
	
}
