package com.Project.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.DAO.RoomRepository;
import com.Project.DAO.Room_BlockingRepository;
import com.Project.Entity.Room;
import com.Project.Entity.Room_Blocking;

@Service
public class RoomService {

	@Autowired
	private RoomRepository roomRepository;
	
	@Autowired
	private Room_BlockingRepository room_blockingRepository;
	
	public List<Room> listAllRoom() {
		List<Room> roomList = (List<Room>) roomRepository.findAll();
		return roomList;
	}

	public List<Room_Blocking> listAllRoomBlocking() {
		List<Room_Blocking> roomBlockingList = (List<Room_Blocking>) room_blockingRepository.findAll();
		return roomBlockingList;
	}

	public boolean checkAvailability(Date date, int roomId) {
		
		boolean result = false;
		List<Room_Blocking> list = room_blockingRepository.getListByDate(date);
		
		for(Room_Blocking x : list)
		{
			if(x.getRoom().getRo_room_number()==roomId)
			{
				result = true;
			}
		}
		return result;
	}

	public void bookRoom(Date date, int roomId) {
		Room_Blocking rb = new Room_Blocking();
		Room r = roomRepository.findOne(roomId);
		rb.setRoom(r);
		rb.setRo_date(date);
		room_blockingRepository.save(rb);
	}

	public void createTables() {
		Room r2 = new Room(1001L);
		Room r1 = new Room(1002L);
		Room r3 = new Room(1003L);
		Room r4 = new Room(1004L);
		Room r5 = new Room(1005L);
		roomRepository.save(r1);
		roomRepository.save(r2);
		roomRepository.save(r3);
		roomRepository.save(r4);
		roomRepository.save(r5);
	}
	
}
