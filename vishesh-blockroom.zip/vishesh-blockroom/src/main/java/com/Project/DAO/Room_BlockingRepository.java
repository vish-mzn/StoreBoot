package com.Project.DAO;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.Project.Entity.Room_Blocking;

@Repository
public interface Room_BlockingRepository extends CrudRepository<Room_Blocking, Integer>{

	@Query("from Room_Blocking rb where rb.ro_date=:date")
	List<Room_Blocking> getListByDate(@Param("date") Date date);

}
