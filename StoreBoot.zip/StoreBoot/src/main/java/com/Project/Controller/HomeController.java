package com.Project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Project.Model.Book;
import com.Project.ServiceLayer.BookService;

@Controller
public class HomeController
{
	@Autowired
	private BookService bookService;
	
	@RequestMapping(value = { "/", "/list"})
	private ModelAndView listBook()
	{
		List<Book> listBook = bookService.listAll();
		return new ModelAndView("BookList", "listBook", listBook);
    }
	
	@RequestMapping(value = {"/new"})
	private ModelAndView showNewForm() 
	{
		return new ModelAndView("BookForm", "newBook", new Book());
    }
	
	@RequestMapping("/edit/{id}")
	private ModelAndView showEditForm(@PathVariable("id") int id)
	{
        Book existingBook = bookService.getBook(id);
        return new ModelAndView("BookForm", "book", existingBook);
    }
	
	@RequestMapping("/insert")
	private ModelAndView insertBook(@ModelAttribute("newBook") Book bo)
	{
		bookService.add(bo);       
		return new ModelAndView("redirect:/list");
    }
	
	@RequestMapping(value = {"/edit/list"})
	private ModelAndView editMapping()
	{
		return new ModelAndView("redirect:/list");
	}
	
	@RequestMapping(value = {"/edit/new"})
	private ModelAndView newMapping()
	{
		return new ModelAndView("redirect:/new");
	}
	
	@RequestMapping("edit/update")
	private ModelAndView updateBook(@ModelAttribute("updatingBook") Book bo)
	{
        bookService.update(bo);       
		return new ModelAndView("redirect:/list");
    }
	
	@RequestMapping("/delete/{id}")
	private String deleteBook(@PathVariable("id") Integer id) 
	{
        bookService.delete(id);
        return "redirect:/list";
    }
	
}