package com.Project.BookDAO;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.Project.Model.Book;

@Component
public class BookDAO
{
	@PersistenceContext
	private EntityManager em;
	
	public void insertBook(Book book)
	{
		em.persist(book);
	}
	
	public List<Book> listAllBooks()
	{
		List<Book> list = new ArrayList<Book>();
		list = (List<Book>)em.createQuery("from Book").getResultList();
		return list;
	}
	
	public void deleteBook(Integer id)
	{
		Book book1 = em.find(Book.class, id);
		em.remove(book1);
	}
	
	public void updateBook(Book book) 
	{   
		em.merge(book);
    }
	
	public Book getBook(Integer id) 
	{
        Book book1 = em.find(Book.class, id);
        return book1;
    }
	
}
